#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a, b, c;

    printf("Enter value for a:");
    scanf("%d", &a);

    printf("Enter value for b:");
    scanf("%d", &b);

    //Arithmatic Operators

    c = a + b;

    printf("Addition is: %d\n", c);

    c = a - b;

    printf("Subtraction is: %d\n", c);

    c = a * b;

    printf("Multiplication is: %d\n", c);

    c = a / b;

    printf("Division is: %d\n", c);

    c = a % b;

    printf("Modulus is: %d\n", c);

    //Pre and Post Increment

    printf("Pre-Increment is: %d\n", ++a); //a=10, 11

    printf("Post-Increment is: %d\n", a++);

    printf("A is %d\n", a); //a=12

    printf("Pre-Decrement is: %d\n", --b); //b=5, 4

    printf("Post-Decrement is: %d\n", b--); //4

    printf("B is: %d\n", b); //3

    return 0;
}
