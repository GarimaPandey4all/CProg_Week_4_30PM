#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number;

    printf("Enter any number");
    scanf("%d", &number);
//    int a, b, c, Largest;
//
//    printf("Enter value for a:");
//    scanf("%d", &a);
//
//    printf("Enter value for b:");
//    scanf("%d", &b);
//
//    printf("Enter value for c:");
//    scanf("%d", &c);
//
//    Largest = (a>b) ? ((a>c)?a : c) : ((b>c)? b:c);

    ((number % 2)==0)? printf("Number is Even") : printf("Number is Odd");

    //printf("Largest Number is: %d", Largest);

    return 0;
}
