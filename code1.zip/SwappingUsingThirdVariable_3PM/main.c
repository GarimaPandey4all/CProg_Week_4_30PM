#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Swapping using third variable

    int a=5, b=7, temp;

    printf("Before Swapping a=%d and b=%d\n", a, b);

    temp = a;
    a = b;
    b = temp;

    printf("After Swapping a=%d and b=%d", a, b);

    return 0;
}
