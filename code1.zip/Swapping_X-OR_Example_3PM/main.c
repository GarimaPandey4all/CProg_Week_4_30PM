#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Swapping without using third varianle

    int A=4, B=9;// 0100, 1001

    //13= 1101

    printf("Before Swapping a=%d and b=%d\n", A, B);

//    A = A ^ B; //A = 13
//    B = A ^ B; //B = 4
//    A = A ^ B; //A = 9
//
//    printf("After Swapping a=%d and b=%d", A, B);

//Second Way: + and - operator

//        A = A + B; //13
//        B = A - B; //4
//        A = A - B;//9
//
//    printf("After Swapping a=%d and b=%d\n", A, B);

    //Third Way: * and / operator

        A = A * B; //36
        B = A / B; //4
        A = A / B;//9

    printf("After Swapping a=%d and b=%d\n", A, B);


    return 0;
}
