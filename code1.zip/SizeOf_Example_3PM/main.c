#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a;
    char b;
    float c;
    double d;


    printf("Size of int is: %u\n", sizeof(int));
    printf("Size of char is: %u\n", sizeof(char));
    printf("Size of float is: %u\n", sizeof(float));
    printf("Size of double is: %u\n", sizeof(double));


    return 0;
}
