#include <stdio.h>
#include <stdlib.h>

int main()
{
     int A=5, B=8;

     //A = 5= 0101, B=8= 1000=

    //Bitwise Operators

    printf("Bitwise AND Operator: %d\n", (A & B));//0
    printf("Bitwise OR Operator: %d\n", (A | B)); //13
    printf("Bitwise NOT Operator: %d\n", (~A)); //1010
    printf("Bitwise X-OR Operator: %d\n", (A ^ B)); //13
    printf("Bitwise Left Shift Operator: %d\n", A<<1); //5 * 2 ^ 1=10
    printf("Bitwise Right Shift Operator: %d\n", B>>1); //8 / 2=4


    return 0;
}
