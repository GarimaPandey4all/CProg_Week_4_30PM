#include <stdio.h>
#include <stdlib.h>


//int array[5]; //Array Declaration

int main()
{

    //Array Initialization

    int array[5]={4,6,8,9,9}; //traditional way

    int array[5]={[3]=8}; //Designated way

    int array[]={4,5,7,7,8,8,9,99}; //compile time initialization

    array[4]=6;

    int array[5]= {6};

    return 0;
}
