#include <stdio.h>
#include <stdlib.h>

int main()
{
    int Array1[2][2][2], Array2[2][2][2], i, j, k;

    printf("Enter values in Array1:");

    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                scanf("%d", &Array1[i][j][k]);
            }

        }
    }

    printf("Enter values in Array2:");

    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                scanf("%d", &Array2[i][j][k]);
            }

        }
    }

    printf("Values in Array1:\n");

    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                printf("%d ", Array1[i][j][k]);
            }
        }
    }

    printf("\nValues in Array2:\n");

    for(i=0; i<2; i++)
    {
        for(j=0; j<2; j++)
        {
            for(k=0; k<2; k++)
            {
                printf("%d ", Array2[i][j][k]);
            }
        }
    }

    return 0;
}
