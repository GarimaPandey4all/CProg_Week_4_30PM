#include <stdio.h>
#include <stdlib.h>

/* Functions has 4 types:

        1. Function without arguments and without return value
        2. Function without arguments and with return value
        3 Function with arguments and without return value
        4. Function with arguments and with return value

function declaration

return_type function_name();

function definition

return_type function_name()
{
function body
}

function calling

function_name();


*/

//Function without arguments and without return value

//Function Declaration

//void Add();
//
//int main()
//{
//    Add();
//    return 0;
//}
//
//void Add()
//{
//    int a, b;
//    printf("Enter value for a and b:");
//    scanf("%d %d", &a, &b);
//
//    printf("Addition is:%d", a+b);
//
//}

//Function without arguments and with return value

//int Add();
//
//int main()
//{
////    int result;
////    result=Add();
////    printf("Addition is: %d", result);
//
//Add();
//    return 0;
//}
//
//int Add()
//{
//    int a, b;
//    printf("Enter value for a and b:");
//    scanf("%d %d", &a, &b);
//
//    printf("Addition is:%d", a+b);
//
//    //return a+b;
//    return 0;
//
//}

//Function with arguments and without return value

//void Add(int, int);
//
//int main()
//{
////    int result;
////    result=Add();
////    printf("Addition is: %d", result);
//    int x,y;
//    Add(x, y);
//    return 0;
//}
//
//void Add(int a, int b)
//{
//
//    printf("Enter value for a and b:");
//    scanf("%d %d", &a, &b);
//
//    printf("Addition is:%d", a+b);
//
//}

//Function with arguments and with return value

int Add(int, int);

int main()
{
//    int result;
//    result=Add();
//    printf("Addition is: %d", result);
    int x,y;
    Add(x, y);
    Add(x, y);
    return 0;
}

int Add(int a, int b)
{

    printf("Enter value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);

    return 0;

}
