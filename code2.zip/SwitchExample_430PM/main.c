#include <stdio.h>
#include <stdlib.h>

int main()
{
    char operator;
    int opr1, opr2;

    printf("Enter any Operator:");
    scanf("%c", &operator);

    switch(operator)
    {
    case '+':
        printf("Enter value for opr1:");
        scanf("%d", &opr1);

        printf("Enter value for opr2:");
        scanf("%d", &opr2);

        printf("Addition is: %d\n", opr1 + opr2);
        break;

    case '-':
        printf("Enter value for opr1:");
        scanf("%d", &opr1);

        printf("Enter value for opr2:");
        scanf("%d", &opr2);

        printf("Subtraction is: %d\n", opr1 - opr2);
        break;

    case '*':
        printf("Enter value for opr1:");
        scanf("%d", &opr1);

        printf("Enter value for opr2:");
        scanf("%d", &opr2);

        printf("Multiplication is: %d\n", opr1 * opr2);
        break;

    case '/':
        printf("Enter value for opr1:");
        scanf("%d", &opr1);

        printf("Enter value for opr2:");
        scanf("%d", &opr2);

        printf("Division is: %d\n", opr1 / opr2);
        break;

    case '%':
        printf("Enter value for opr1:");
        scanf("%d", &opr1);

        printf("Enter value for opr2:");
        scanf("%d", &opr2);

        printf("Modulus is: %d\n", opr1 % opr2);
        break;

    default:
        printf("You have entered the wrong operator");

    }

    return 0;
}
