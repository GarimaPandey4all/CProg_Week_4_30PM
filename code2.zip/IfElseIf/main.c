#include <stdio.h>
#include <stdlib.h>

//    1. If-else

//if()
//{
//
//}
//
//else
//{
//
//}

//    2. If-Else if-else
//
//if()
//{
//
//}
//
//else if()
//{
//
//}
//
//else
//{
//
//}

int main()
{
    int marks[5], i, sum=0, percentage;

    printf("Enter marks in an array:");
    for(i=0; i<5; i++)
    scanf("%d", &marks[i]);

    for(i=0; i<5; i++)
        sum += marks[i];

    printf("Sum is:%d\n", sum);

    percentage = (sum / 5);

    printf("Percentage is:%d\n", percentage);

    if(percentage >= 50 && percentage <= 60)
        printf("D- Grade\n");

    else if(percentage >= 60 && percentage <= 70)
        printf("C- Grade\n");

    else if(percentage >= 70 && percentage <= 80)
        printf("B- Grade\n");

    else if(percentage >= 80 && percentage <= 100)
        printf("A- Grade\n");

    else
        printf("Otherwise Fail");

    return 0;
}


