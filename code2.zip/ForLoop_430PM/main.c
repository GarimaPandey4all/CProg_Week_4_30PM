#include <stdio.h>
#include <stdlib.h>

/*for(initialization; condition; increment/decrement)
{

}

int n;

n=5;
while(condition)
{

increment/decrement
}

initialization
do
{
increment/decrement
}while(condition);



*/

int main()
{
    int i, n;

    printf("Enter any number to print any number's table:");
    scanf("%d", &n);

    printf("Table of %d:\n", n);
    for(i=1; i<=10; i++)
    {
        printf("%d * %d = %d\n", n, i, n*i);
        /*5 * 1= 5*/
    }

    return 0;
}
