#include <stdio.h>
#include <stdlib.h>

int main()
{
   /*Menu Driven Program with Switch*/
    int choice,a,b,c,Largest,number;

//for(;;)
while(1)
{
   printf("Press 1. Addition\n");
   printf("Press 2. X-OR\n");
   printf("Press 3. Even-Odd\n");
   printf("Press 4. Left Shift\n");
   printf("Press 5. Right Shift\n");
   printf("Press 6. Pre-Increment Shift\n");
   printf("Press 7. Largest Number\n");
   printf("Press 8. Exit\n");
   printf("Enter your Choice");
   scanf("%d", &choice);

   switch(choice)
   {
   case 1:

    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is: %d\n", a + b);

    break;

   case 2:

    printf("Enter values for a and b:");
    scanf("%d %d", &a, &b);

    printf("X-OR is: %d\n", (a ^ b));

    break;

   case 3:

    printf("Enter any Number:");
    scanf("%d", &number);

    ((number % 2)==0)? printf("Number is Even\n") : printf("Number is Odd\n");

    break;

   case 4:

    printf("Enter values for a:");
    scanf("%d", &a);

    printf("Left Shift is: %d\n", a<<1);

    break;

   case 5:

    printf("Enter values for b:");
    scanf("%d", &b);

    printf("Right Shift is: %d\n", b>>1);

    break;

    case 6:

    printf("Enter values for a:");
    scanf("%d", &a);

    printf("Pre-Increment is: %d\n", ++a);

    break;

    case 7:

    printf("Enter values for a, b, and c:");
    scanf("%d %d %d", &a, &b, &c);

    Largest = (a>b) ? ((a>c)?a:c) : ((b>c)?b:c);

    printf("Largest number is: %d\n", Largest);

    break;

    case 8:
        exit(0);

    default:
        printf("You have entered the wrong case");
   }
}

    return 0;
}
