#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i=1;
    while(i<=10){
        printf("Counter is:%d\n", i);
        i++;
    }

    return 0;
}
